import json
import math
import random
import urllib.request
from datetime import datetime, timedelta

# --- 1. SIMULATED MODEL (Dependency-Free) ---
class EnergyModel:
    def __init__(self, solar_capacity=100.0, wind_capacity=100.0):
        self.solar_capacity = solar_capacity
        self.wind_capacity = wind_capacity

    def get_solar_power(self, hour: float, cloud_cover: float = 0.0) -> float:
        if hour < 6 or hour > 18:
            return 0.0
        
        mu = 12.0
        sigma = 2.5
        intensity = math.exp(-0.5 * ((hour - mu) / sigma) ** 2)
        actual_power = self.solar_capacity * intensity * (1.0 - cloud_cover)
        
        # Random noise (using standard random instead of numpy)
        noise = random.gauss(0, 2)
        return max(0.0, actual_power + noise)

    def get_wind_power(self, hour: float, wind_speed_factor: float = 0.5) -> float:
        base = math.sin(hour / 4.0) * 0.2 + 0.5
        gust = random.gauss(0, 0.1)
        total_intensity = max(0.0, min(1.0, base + wind_speed_factor + gust))
        return self.wind_capacity * total_intensity

    def get_carbon_intensity(self, hour: float) -> float:
        base_intensity = 400.0
        morning_peak = 100 * math.exp(-0.5 * ((hour - 9) / 1.5) ** 2)
        evening_peak = 150 * math.exp(-0.5 * ((hour - 19) / 2.0) ** 2)
        return base_intensity + morning_peak + evening_peak

# --- 2. REAL MODEL (Open-Meteo) ---
def fetch_real_weather(lat=39.0438, lon=-77.4874):
    # Fetch today's forecast/history
    end_date = datetime.now().strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    
    url = f"https://archive-api.open-meteo.com/v1/archive?latitude={lat}&longitude={lon}&start_date={start_date}&end_date={end_date}&hourly=temperature_2m,direct_radiation,wind_speed_10m&timezone=auto"
    
    try:
        with urllib.request.urlopen(url) as response:
            if response.status == 200:
                data = json.loads(response.read().decode())
                return data
            else:
                return {"error": f"API returned status {response.status}"}
    except Exception as e:
        return {"error": str(e)}

# --- 3. LAMBDA HANDLER ---
def lambda_handler(event, context):
    """
    Query Params:
    - mode: 'simulated' (default) or 'real'
    - hour: 0-23 (for simulated)
    - lat, lon: (for real)
    """
    params = event.get('queryStringParameters', {}) or {}
    mode = params.get('mode', 'simulated')
    
    response_body = {}
    
    if mode == 'real':
        lat = params.get('lat', 39.0438)
        lon = params.get('lon', -77.4874)
        data = fetch_real_weather(lat, lon)
        response_body = {
            "source": "Open-Meteo API",
            "data": data
        }
    else:
        # Simulated Mode
        try:
            hour = float(params.get('hour', 12.0))
        except ValueError:
            hour = 12.0
            
        model = EnergyModel()
        solar = model.get_solar_power(hour)
        wind = model.get_wind_power(hour)
        carbon = model.get_carbon_intensity(hour)
        
        response_body = {
            "source": "Internal Simulation Model",
            "params": {"hour": hour},
            "prediction": {
                "solar_power_kw": round(solar, 2),
                "wind_power_kw": round(wind, 2),
                "carbon_intensity_g_kwh": round(carbon, 2)
            }
        }

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps(response_body)
    }
